# KisaanConnect - Enhanced (React + Node.js)

This scaffold was generated automatically. It contains:

- `backend/` - Express + file-based JSON DB with basic auth and crops CRUD.
- `frontend/` - Vite + React app (Tailwind via CDN for quick prototyping).

## Quick start (locally)
1. Unzip the package.
2. Backend:
   - cd backend
   - npm install
   - set environment variable JWT_SECRET (or edit index.js default)
   - npm run dev
3. Frontend:
   - cd frontend
   - npm install
   - npm run dev
4. Open the frontend dev URL (usually http://localhost:5173) and backend on port 4000.

## Enhancements included
- Responsive UI with Tailwind (CDN)
- Simple auth (register/login) with JWT
- Crops marketplace CRUD (file-based)
- Placeholders for Weather & News proxy endpoints (server-side)
- Readme & examples

## Next recommended steps
- Replace file-based DB with MongoDB or Postgres.
- Add real weather/news integrations (set API keys on server).
- Add image upload for crops (S3 or Cloudinary).
- Add pagination, search, and filters to Marketplace.
- Improve UI with Tailwind config and components.

